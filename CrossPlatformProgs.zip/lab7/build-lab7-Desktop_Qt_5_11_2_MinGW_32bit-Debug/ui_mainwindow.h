/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.11.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QWidget *layoutWidget;
    QGridLayout *gridLayout;
    QPushButton *getButton;
    QPushButton *postButton;
    QLabel *urlLabel;
    QLineEdit *urlLine;
    QLabel *dataLabel;
    QLineEdit *dataLine;
    QPushButton *submitButton;
    QPushButton *resetButton;
    QLabel *responseTitleLabel;
    QTextBrowser *textBrowser;
    QLabel *label;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(360, 530);
        MainWindow->setAutoFillBackground(true);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        layoutWidget = new QWidget(centralWidget);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(11, 121, 316, 304));
        gridLayout = new QGridLayout(layoutWidget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        getButton = new QPushButton(layoutWidget);
        getButton->setObjectName(QStringLiteral("getButton"));

        gridLayout->addWidget(getButton, 0, 0, 1, 1);

        postButton = new QPushButton(layoutWidget);
        postButton->setObjectName(QStringLiteral("postButton"));

        gridLayout->addWidget(postButton, 0, 2, 1, 1);

        urlLabel = new QLabel(layoutWidget);
        urlLabel->setObjectName(QStringLiteral("urlLabel"));

        gridLayout->addWidget(urlLabel, 1, 0, 1, 1);

        urlLine = new QLineEdit(layoutWidget);
        urlLine->setObjectName(QStringLiteral("urlLine"));

        gridLayout->addWidget(urlLine, 1, 1, 1, 2);

        dataLabel = new QLabel(layoutWidget);
        dataLabel->setObjectName(QStringLiteral("dataLabel"));

        gridLayout->addWidget(dataLabel, 2, 0, 1, 1);

        dataLine = new QLineEdit(layoutWidget);
        dataLine->setObjectName(QStringLiteral("dataLine"));

        gridLayout->addWidget(dataLine, 2, 1, 1, 2);

        submitButton = new QPushButton(layoutWidget);
        submitButton->setObjectName(QStringLiteral("submitButton"));

        gridLayout->addWidget(submitButton, 3, 0, 1, 1);

        resetButton = new QPushButton(layoutWidget);
        resetButton->setObjectName(QStringLiteral("resetButton"));

        gridLayout->addWidget(resetButton, 3, 2, 1, 1);

        responseTitleLabel = new QLabel(layoutWidget);
        responseTitleLabel->setObjectName(QStringLiteral("responseTitleLabel"));

        gridLayout->addWidget(responseTitleLabel, 4, 0, 1, 1);

        textBrowser = new QTextBrowser(layoutWidget);
        textBrowser->setObjectName(QStringLiteral("textBrowser"));

        gridLayout->addWidget(textBrowser, 4, 1, 1, 2);

        label = new QLabel(centralWidget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(10, 50, 311, 41));
        MainWindow->setCentralWidget(centralWidget);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", nullptr));
        getButton->setText(QApplication::translate("MainWindow", "Get", nullptr));
        postButton->setText(QApplication::translate("MainWindow", "Post", nullptr));
        urlLabel->setText(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Enter Url</p></body></html>", nullptr));
        dataLabel->setText(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:8pt;\">Enter Data</span></p></body></html>", nullptr));
        submitButton->setText(QApplication::translate("MainWindow", "Submit", nullptr));
        resetButton->setText(QApplication::translate("MainWindow", "Reset", nullptr));
        responseTitleLabel->setText(QApplication::translate("MainWindow", "Response", nullptr));
        label->setText(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:10pt; font-weight:600;\">Http Get and Post</span></p></body></html>", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
