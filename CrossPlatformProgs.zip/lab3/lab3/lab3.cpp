#include "lab3.h"
#include "ui_lab3.h"

lab3::lab3(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::lab3)
{
    ui->setupUi(this);
}

lab3::~lab3()
{
    delete ui;
}
void lab3::on_pushButton_clicked()
{
    bool chechEmail=false;
    QString oldText = ui->lineEdit_2->text();
    int pos_a=-1;
    for(int i=0; i<oldText.count();i++)
        if (oldText[i]=='@') pos_a=i;
    if ((pos_a<=0)||(pos_a>oldText.count()-4))chechEmail=true;


    if (ui->lineEdit->text() == ""
            || ui->textEdit->toPlainText() == ""
            || (not ui->radioButton->isChecked()
            && not ui->radioButton_2->isChecked()
            && not ui->radioButton_3->isChecked()
            && not ui->radioButton_4->isChecked()
            && not ui->radioButton_5->isChecked())
            || chechEmail==true){
        QMessageBox::critical(this, "А-я-яй", "Просили же <<Заполните все поля>>");
    } else {
        QMessageBox::information(this, "Всё ОК", "Спасибо за отзыв");
    }
}
