/********************************************************************************
** Form generated from reading UI file 'lab3.ui'
**
** Created by: Qt User Interface Compiler version 5.11.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LAB3_H
#define UI_LAB3_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_lab3
{
public:
    QWidget *centralWidget;
    QGridLayout *gridLayout;
    QLineEdit *lineEdit;
    QLineEdit *lineEdit_2;
    QPushButton *pushButton;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QRadioButton *radioButton;
    QRadioButton *radioButton_2;
    QRadioButton *radioButton_3;
    QRadioButton *radioButton_4;
    QRadioButton *radioButton_5;
    QTextEdit *textEdit;
    QLabel *label_2;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *lab3)
    {
        if (lab3->objectName().isEmpty())
            lab3->setObjectName(QStringLiteral("lab3"));
        lab3->resize(336, 446);
        centralWidget = new QWidget(lab3);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        gridLayout = new QGridLayout(centralWidget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        lineEdit = new QLineEdit(centralWidget);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        QFont font;
        font.setPointSize(12);
        lineEdit->setFont(font);

        gridLayout->addWidget(lineEdit, 1, 0, 1, 1);

        lineEdit_2 = new QLineEdit(centralWidget);
        lineEdit_2->setObjectName(QStringLiteral("lineEdit_2"));
        lineEdit_2->setFont(font);
        lineEdit_2->setFrame(true);
        lineEdit_2->setEchoMode(QLineEdit::Normal);
        lineEdit_2->setReadOnly(false);

        gridLayout->addWidget(lineEdit_2, 2, 0, 1, 1);

        pushButton = new QPushButton(centralWidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setFont(font);
        pushButton->setCursor(QCursor(Qt::ArrowCursor));

        gridLayout->addWidget(pushButton, 5, 0, 1, 1);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        label = new QLabel(centralWidget);
        label->setObjectName(QStringLiteral("label"));
        label->setFont(font);

        horizontalLayout->addWidget(label);

        radioButton = new QRadioButton(centralWidget);
        radioButton->setObjectName(QStringLiteral("radioButton"));
        QFont font1;
        font1.setPointSize(10);
        radioButton->setFont(font1);
        radioButton->setCursor(QCursor(Qt::ArrowCursor));
        radioButton->setChecked(false);

        horizontalLayout->addWidget(radioButton);

        radioButton_2 = new QRadioButton(centralWidget);
        radioButton_2->setObjectName(QStringLiteral("radioButton_2"));
        radioButton_2->setFont(font1);
        radioButton_2->setChecked(false);
        radioButton_2->setAutoExclusive(true);

        horizontalLayout->addWidget(radioButton_2);

        radioButton_3 = new QRadioButton(centralWidget);
        radioButton_3->setObjectName(QStringLiteral("radioButton_3"));
        radioButton_3->setFont(font1);
        radioButton_3->setAutoExclusive(true);

        horizontalLayout->addWidget(radioButton_3);

        radioButton_4 = new QRadioButton(centralWidget);
        radioButton_4->setObjectName(QStringLiteral("radioButton_4"));
        radioButton_4->setFont(font1);

        horizontalLayout->addWidget(radioButton_4);

        radioButton_5 = new QRadioButton(centralWidget);
        radioButton_5->setObjectName(QStringLiteral("radioButton_5"));
        radioButton_5->setFont(font1);

        horizontalLayout->addWidget(radioButton_5);


        gridLayout->addLayout(horizontalLayout, 3, 0, 1, 1);

        textEdit = new QTextEdit(centralWidget);
        textEdit->setObjectName(QStringLiteral("textEdit"));
        textEdit->setFont(font);

        gridLayout->addWidget(textEdit, 4, 0, 1, 1);

        label_2 = new QLabel(centralWidget);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setFont(font);
        label_2->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_2, 0, 0, 1, 1);

        lab3->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(lab3);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 336, 20));
        lab3->setMenuBar(menuBar);
        mainToolBar = new QToolBar(lab3);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        lab3->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(lab3);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        lab3->setStatusBar(statusBar);

        retranslateUi(lab3);

        QMetaObject::connectSlotsByName(lab3);
    } // setupUi

    void retranslateUi(QMainWindow *lab3)
    {
        lab3->setWindowTitle(QApplication::translate("lab3", "lab3", nullptr));
        lineEdit->setText(QString());
        lineEdit->setPlaceholderText(QApplication::translate("lab3", "\320\222\320\262\320\265\320\264\320\270\321\202\320\265 \320\270\320\274\321\217", nullptr));
        lineEdit_2->setText(QString());
        lineEdit_2->setPlaceholderText(QApplication::translate("lab3", "\320\222\320\262\320\265\320\264\320\270\321\202\320\265 e-mail", nullptr));
        pushButton->setText(QApplication::translate("lab3", "\320\236\321\202\320\277\321\200\320\260\320\262\320\270\321\202\321\214", nullptr));
        label->setText(QApplication::translate("lab3", "\320\236\321\206\320\265\320\275\320\272\320\260", nullptr));
        radioButton->setText(QApplication::translate("lab3", "1", nullptr));
        radioButton_2->setText(QApplication::translate("lab3", "2", nullptr));
        radioButton_3->setText(QApplication::translate("lab3", "3", nullptr));
        radioButton_4->setText(QApplication::translate("lab3", "4", nullptr));
        radioButton_5->setText(QApplication::translate("lab3", "5", nullptr));
        textEdit->setPlaceholderText(QApplication::translate("lab3", "\320\236\321\201\321\202\320\260\320\262\321\214\321\202\320\265 \321\201\320\262\320\276\320\271 \320\276\321\202\320\267\321\213\320\262", nullptr));
        label_2->setText(QApplication::translate("lab3", "\320\227\320\260\320\277\320\276\320\273\320\275\320\270\321\202\320\265 \320\262\321\201\320\265 \320\277\320\276\320\273\321\217", nullptr));
    } // retranslateUi

};

namespace Ui {
    class lab3: public Ui_lab3 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LAB3_H
