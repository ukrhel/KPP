#ifndef READWRITE_H
#define READWRITE_H

#include <QtGui/QGuiApplication>
#include <QFile>
#include <QTextStream>

class ReadWrite : public QObject
{
    Q_OBJECT

public:
    ReadWrite(QObject *parent = 0);

    QString curText;

    Q_PROPERTY(QString curText READ readTextFromFile)

    Q_INVOKABLE void saveTextToFile(QString text );
    Q_INVOKABLE QString readTextFromFile();

    ~ReadWrite();

private:
    QString FILENAME;

};

#endif // READWRITE_H
