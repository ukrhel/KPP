#include "readwrite.h"

ReadWrite::ReadWrite(QObject *parent):
    QObject(parent)
{
    this->FILENAME = QString("text.txt");
}

ReadWrite::~ReadWrite()
{
}

void ReadWrite::saveTextToFile(QString text)
{
    QFile file(FILENAME);
    if (file.open(QFile::ReadWrite | QIODevice::Truncate)) {
        QTextStream outStream(&file);
        outStream << text;
    }
    file.close();
}

QString ReadWrite::readTextFromFile()
{
    QFile file(FILENAME);
    if (file.open(QFile::ReadWrite)) {
        QTextStream inStream(&file);
        curText = inStream.readAll();
    }
    file.close();
    return curText;
}
