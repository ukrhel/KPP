#include <QtGui/QGuiApplication>
#include <QQmlContext>
#include <QQmlEngine>
#include <QQuickView>
#include "qtquick2applicationviewer.h"
#include "readwrite.h"

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    QtQuick2ApplicationViewer viewer;

    viewer.setMainQmlFile(QStringLiteral("qml/lab5/main.qml"));
    viewer.rootContext()->setContextProperty("readwrite", new ReadWrite());
    viewer.showExpanded();

    return app.exec();
}
