#include "lab6.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    lab6 w;
    w.show();

    return a.exec();
}
