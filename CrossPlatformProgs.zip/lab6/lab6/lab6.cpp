#include "lab6.h"
#include "ui_lab6.h"

lab6::lab6(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::lab6)
{
    ui->setupUi(this);
    QString DBpath = QDir::toNativeSeparators("D:\\sqlite\\student.db");
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName(DBpath);
    if(!db.open()) {
        QMessageBox::critical(this, tr("SQLite connection"), tr("Unable connect to DB, check file permission."));
        exit(1);
    } else {
        QMessageBox::about(this, tr("SQLite connection"), tr("Connection successful"));
    }
    model = new QSqlTableModel(ui->tableView);
    model->setTable("Student");
    model->setEditStrategy(QSqlTableModel::OnFieldChange);
    model->select();
    ui->tableView->setModel(model);
}

lab6::~lab6()
{
    delete ui;
}

void lab6::on_add_clicked()
{
    QString id = ui->ID->text();
    QString name = ui->fio->text();
    QString form = ui->form->text();
    QString gpa = ui->gpa->text();
    QString group = ui->group->text();
    QSqlQuery query;
    query.prepare("INSERT INTO student (id, Name, GPA, EducForm, GroupId ) "
              "VALUES (:id, :name, :GPA, :EducForm, :Group)");
    query.bindValue(":id", id);
    query.bindValue(":name", name);
    query.bindValue(":GPA", gpa);
    query.bindValue(":EducForm", form);
    query.bindValue(":Group", group);
    query.exec();
    model->select();
    ui->tableView->setModel(model);

}

void lab6::on_delete_2_clicked()
{
    QModelIndexList indexes = ui->tableView->selectionModel()->selection().indexes();
    QSet<int> *rowsToDelete = new QSet<int>();
    for (int i = 0; i < indexes.count(); ++i) {
        QModelIndex index = indexes.at(i);
        rowsToDelete->insert(index.row());
    }

    QSet<int>::iterator i;
    for (i = rowsToDelete->begin(); i != rowsToDelete->end(); ++i) {
        model->removeRow(*i);
    }
    model->select();
    ui->tableView->setModel(model);

}
