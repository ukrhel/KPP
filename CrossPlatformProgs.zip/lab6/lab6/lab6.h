#ifndef LAB6_H
#define LAB6_H

#include <QMainWindow>
#include <QtSql/QSqlDatabase>
#include <QMessageBox>
#include <QtSql>
#include <QSqlQuery>

namespace Ui {
class lab6;
}

class lab6 : public QMainWindow
{
    Q_OBJECT

public:
    QSqlDatabase db;
    explicit lab6(QWidget *parent = 0);
    ~lab6();

private slots:
    void on_add_clicked();

    void on_delete_2_clicked();

private:
    Ui::lab6 *ui;
    QSqlTableModel *model;
};

#endif // LAB6_H
